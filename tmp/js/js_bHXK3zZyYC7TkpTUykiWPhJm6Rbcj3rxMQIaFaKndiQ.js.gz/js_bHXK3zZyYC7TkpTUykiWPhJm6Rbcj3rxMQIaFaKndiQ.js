/* @license GPL-2.0-or-later https://www.drupal.org/licensing/faq */
jQuery,Drupal,Drupal.behaviors.map={attach:function(a,e){mapboxgl.accessToken="pk.eyJ1IjoibWlkY2FtcCIsImEiOiJjaXV2czRteHQwNGhkMm9zNWp4bWhndTk0In0.F5jwcKus8Rzx5r8Ga-CRQA",new mapboxgl.Map({container:"map",style:"mapbox://styles/midcamp/ciuvsjxje00312ipqrfyxm4di",center:[-87.66,41.924],zoom:15}).scrollZoom.disable();}};;
